
class RoutesConstant {
  static String addForm = '/formadd_page.dart';
  static String home = '/home_page_view.dart';
  static String item = '/items_add_page.dart';
  static String phone = '/phone_page.dart';
  static String otp = '/otp_screen_view.dart';
  static String imgupload = '/img_upload_page.dart';
}