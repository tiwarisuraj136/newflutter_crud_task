import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PhoneController extends GetxController{
  TextEditingController phoneNumController = TextEditingController();
}